
<?php
session_start();
$mail=$_SESSION['email'];

?>

<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968021/font-owsome/all_nyeyid.css" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css2?family=Karla:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">
  <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1603531914/norm_used/loader_ww3kih.css">
<style>

@import url(https://fonts.googleapis.com/css?family=Arvo);
@import url(http://fonts.googleapis.com/css?family=Varela+Round);
.tablediv{
    padding:10%;
}
tr{

border:1px solid #dedddc;
}


.con-of-tbl{
background:white;
border-radius:4px;
}

.col-header th{
padding-top:1rem !important;
padding-bottom:1rem !important;
}
.col-header{


color: white;
    font-size: 20px !important;
    background: darkcyan;
    font-weight: 700 !important;


}
.first-col{

display: block;
    
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

body{



webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{

border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#007c89;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}
button:focus{
    outline:none;
}
.btn-my:hover{
    border:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    padding:inherit;height:50px;text-align:center;background:#f2f2f2;border:none;
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}
#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}


























.head-dash{
  font-family: 'Karla', sans-serif;
  font-size: 23px;
  color: #000000e0;
  width:50%;
}
body{
	
}

.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}

.row{
	width:100%;
	margin-left:0px;
	margin-right: 0px;
}
.head-con-rw{
	padding-top: 20px;
	padding-bottom: 20px;
}
.btn-con-top{
	width: 50%;
}

.bottom-btn:hover{
	cursor: pointer;
}







body{




webkit-font-smoothing: antialiased;}
.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}
.modal-text p{


font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
    font-weight: 400;
    letter-spacing: 0.7px;
    color: #241c15;



}
.modal-btn:hover{
transition:background-color 0.2s ease-in-out 0s, opacity 0.2s ease-in-out 0s;
cursor:pointer;
background:#2296a3;

}
.modal-btn{
border-radius:4px;
border:none;
outline:none;
height:40px;
font-size:15px;
letter-spacing:0.6px;
color:white;
padding-left:10px;
padding-right:10px;
background:#085861;
font-weight:900;
}

.modal-text{
font-family: "Graphik Web","Helvetica Neue",Helvetica,Arial,Verdana,sans-serif;
padding-right:100px;
text-align: left;
    padding-left: 100px;
    padding-top: 40px;
    padding-bottom: 40px;
}








.con-of-dash-data{
	width:25%;
	margin: 0px auto;


}
.con-ch-dast-data{
text-align: center;
	border-radius: 5px;
	background:white;
	margin: 20px;

}

.icon-data-con{

	padding-top: 20px;
    padding-bottom: 20px;
}



.ico-fa-data{

	display: table-cell;
	vertical-align: middle;

    font-size: 30px;

    height: 60px;
    width:60px;
}




.con-ico-data{


    width: fit-content;
    margin: 0px auto;
    border-radius: 50%;
    height: 60px;
    width:60px;
}

.data-info-text{
  color: black;
  font-size: 37px;
  font-weight: bolder;
  padding-top: 10px;
    padding-bottom: 10px;
}

.data-head-line{
  padding-top: 10px;
    padding-bottom: 20px;
  color: #04040485;
    font-weight: 600;
}


.head-of-over{
  font-family: 'Karla', sans-serif;
  font-size: 20px;
  color: #000000e0;
  padding-top: 20px;
}



.table{
margin-bottom:0px;
}











.data-tbl-db{
 
  background: white;
  border-radius: 5px;
  
}

.data-belo-line{

    width: 500px;
    overflow: scroll;
    font-weight: 600;
    color: #0000006b;
}

.tbl-main-head{
  color: #000000cc;
    font-weight: bolder;
width: 200px;
    overflow-x: scroll;
}
.tbl-main-head::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE and Edge */
.tbl-main-head {
  -ms-overflow-style: none;
}

.tbl-link-clr{
  color: blue;
transition:.2s;



}


.tbl-link-clr:hover{
color:black;

}











.not-fd-data{
  text-align: center;
background:white;
border-radius:4px;

padding:20px;





}








.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

















@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);


.nav-link:hover{
    cursor:pointer;
}

ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;

}
.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}


td{
vertical-align: middle;

}

html{
background;#f0f8ffcf;
}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.con-of-tbl{
background:white;
border-radius:4px;
}
















button.btn_hover_clr {
    

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
    background: white;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }



.table td, .table th {
    font-size: 16px;
    white-space: nowrap;

  }












.tooltip2 .tooltiptext {
    visibility: hidden;
    width: 120px;
    font-size: 13px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
    position: absolute;
    z-index: 1;
    margin-left: -60px;
    margin-top: 20px;
    font-family: 'IBM Plex Sans', sans-serif;
    font-weight: 500;
  }
.tooltip2:hover .tooltiptext {
  visibility: visible;
}













.lds-color div{

border: 2px solid #4a154bd9;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
 
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

.lds-large div{
  width: 40px;
  height: 40px;
  border: 4px solid;

}



.lds-large {
    margin: auto;
    
    width: 40px;
    height: 40px;

  }

.main-content {
  height: 92vh;
  overflow: scroll;
}

   .lds-main-large{
top: 300px;
    left: 50%;

  }







i:hover{

  cursor: pointer;

}






.card{
  height: min-content;
  width: 30rem;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{

    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;
  }

.container-2GnNH span{

font-size: 13px;

}

.side-nav-menu {
    width: 20%;
   
    
  }

  .head-name-opt {
    color: #241c15;
    font-weight: 500;
    font-size: 14px;
    padding: 20px 0px;
  }

  .main-opt-trg {
    padding: 8px 8px;
    color: #737373;
    border-radius: 3px;
font-size: 13px;
  }

  i.fal {
    padding-right: 10px;
    color: #6d6b6b;
  }


  .main-res-con {
    width: 80%;
}

.all-opt-name {
    padding: 20px;
  }

.part-sid-men {
    border-top: 1px solid #dedddc;

  }

  .main-opt-trg:hover{
    background: #f8f8f8;
color: black;
    cursor: pointer;
  }

  input.ip-srch {
    width: 100%;
    height: 40px;
    border: 1px solid #908e8e;
    border-radius: 10px;
    padding: 0px 10px;

  }


  input:focus {
    color: #495057;
    background-color: #fff;
    border-color: #80bdff;
    outline: 0;
    box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
  }














  .checkbox {
  --background: #fff;
  --border: #d1d6ee;
  --border-hover: #bbc1e1;
  --border-active: #1e2235;
  --tick: #fff;
  position: relative;
}
.checkbox input,
.checkbox svg {
  width: 21px;
  height: 21px;
  display: block;
}
.checkbox input {
  -webkit-appearance: none;
  -moz-appearance: none;
  position: relative;
  outline: none;
  background: var(--background);
  border: none;
  margin: 0;
  padding: 0;
  cursor: pointer;
  border-radius: 4px;
  -webkit-transition: box-shadow 0.3s;
  transition: box-shadow 0.3s;
  box-shadow: inset 0 0 0 var(--s, 1px) var(--b, var(--border));
}
.checkbox input:hover {
  --s: 2px;
  --b: var(--border-hover);
}
.checkbox input:checked {
  --b: var(--border-active);
}
.checkbox svg {
  pointer-events: none;
  fill: none;
  stroke-width: 2px;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke: var(--stroke, var(--border-active));
  position: absolute;
  top: 0;
  left: 0;
  width: 21px;
  height: 21px;
  -webkit-transform: scale(var(--scale, 1)) translateZ(0);
          transform: scale(var(--scale, 1)) translateZ(0);
}
.checkbox.path input:checked {
  --s: 2px;
  -webkit-transition-delay: 0.4s;
          transition-delay: 0.4s;
}
.checkbox.path input:checked + svg {
  --a: 16.1 86.12;
  --o: 102.22;
}
.checkbox.path svg {
  stroke-dasharray: var(--a, 86.12);
  stroke-dashoffset: var(--o, 86.12);
  -webkit-transition: stroke-dasharray 0.6s, stroke-dashoffset 0.6s;
  transition: stroke-dasharray 0.6s, stroke-dashoffset 0.6s;
}
.checkbox.bounce {
  --stroke: var(--tick);
}
.checkbox.bounce input:checked {
  --s: 11px;
}
.checkbox.bounce input:checked + svg {
  -webkit-animation: bounce 0.4s linear forwards 0.2s;
          animation: bounce 0.4s linear forwards 0.2s;
}
.checkbox.bounce svg {
  --scale: 0;
}

@-webkit-keyframes bounce {
  50% {
    -webkit-transform: scale(1.2);
            transform: scale(1.2);
  }
  75% {
    -webkit-transform: scale(0.9);
            transform: scale(0.9);
  }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
}

@keyframes bounce {
  50% {
    -webkit-transform: scale(1.2);
            transform: scale(1.2);
  }
  75% {
    -webkit-transform: scale(0.9);
            transform: scale(0.9);
  }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
}

div#all-res-of-query {
    padding: 0px 40px 0px 40px;
    height: 500px;
    overflow: scroll;
    margin-top: 40px;
  }

    .main-con-of-camp-name {
    width: 100%;
    padding: 30px 0px;
    border-bottom: 1px solid #e0e0e0;
  }

  .main-name-camp {
    width: 100%;
  }

  .main-name-camp div {
    display: inline-table;
  }

  .main-name-sel-one-camp {
    width: 5%;
    
    
  }

  .get-stat-of-camp {
    width: 20%;
    text-align: right;
font-size: 20px;
  }
  .blck_spc {
    width: 28%;
    
   

  }

  .init-opt-for-camp {
    width: 20%;
  
   
  }

  .name-hold-of-camp {
    width: 25%;
    
  
  }

span.txt-name-of-camp {
    color: #007c89;
    font-size: 1rem;
    line-height: inherit;
}

span.text-type-of-camp {
    color: #484848;
    font-size: 15px;
    }

   .text-date-of-camp {
    margin-top: 30px;
    color: #737373;
    font-weight: 400;
    font-size: 13px;
  }

  .badge-dark {
    color: #090c0efa;
    background-color: rgb(90 101 112 / 18%);
  }

  button.without-back-btn {
    transition: .2s;
    background: no-repeat;
    border: 0px;
    height: 40px;
    width: 40px;
    border-radius: 50%;

  }

  button.without-back-btn:hover {
    background: #00000029 !important;
    cursor: pointer;

  }
.ico-of-camp-dis{
  font-size: 20px;
  color: #a09696;
}

.not-fd-con {
    width: 100%;
    height: 500px;
    text-align: center;

    }

    img.not-fd-camp {
    width: 300px;
  }
  p.txt-of-not-fd {
    font-size: 15px;
    color: black;
    font-weight: 600;
    padding-top: 20px;
  }

  .head-of-main-con {
    text-align: center;
  }

  #all-res-of-query::-webkit-scrollbar {
    display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
#all-res-of-query {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}



















.modal-2 {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal-2.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal-2.open > .content-wrapper {
  transform: scale(1);
}
.modal-2 .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal-2 .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal-2 .content-wrapper .close:before, .modal-2 .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal-2 .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal-2 .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal-2 .content-wrapper .close:hover:before, .modal-2 .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal-2 .content-wrapper .modal-2-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal-2 .content-wrapper .modal-2-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal-2 .content-wrapper .content {
    position: relative;
    display: flex;
    text-align: center;
    color: #504b4b;
  }
.modal-2 .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal-2 .content-wrapper .modal-2-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal-2 .content-wrapper .modal-2-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal-2 .content-wrapper .modal-2-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal-2 .content-wrapper .modal-2-footer .action:first-child {
  background-color: #2ecc71;
}
.modal-2 .content-wrapper .modal-2-footer .action:last-child {
  background-color: #e74c3c;
}
.modal-2 .content-wrapper .modal-2-footer .action:hover:before {
  width: 100%;
}






.modal-2-header h2{

  color: black;
}







.del_ico_conf_dis {
    border-radius: 50%;
    padding: 30px;
    margin-bottom: 30px;
    box-shadow: 5px 5px 10px grey;
  }

  .head-line-of-mdl h4 {
    color: black;
  }

  .btn-con-del-camp {
    width: 100%;

  }

svg.svg-ico-of-dt {
    margin-right: 20px;
  }




button.btn-theme-dsg {
  font-family 'IBM Plex Sans', sans-serif !important: 
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-box-pack: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
    font-size: 14px;
    line-height: 1.5;
    font-weight: 500;
    border-radius: 4px;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 0;
    -webkit-appearance: none;
    position: relative;
    -webkit-transition-property: background-color,border-color,color;
    transition-property: background-color,border-color,color;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: 100%;
    min-width: 0;
    -webkit-flex: 0 0 auto;
    -ms-flex: 0 0 auto;
    flex: 0 0 auto;
    font-family: 'Roboto';
    color: #FFFFFF;
    background-color: #4a154b;
    padding-right: 16px;
    padding-left: 16px;
    margin: 8px 0px;
    height: 48px;


  }


button.close-2 {
    padding: 0;
    background-color: transparent;
    border: 0;
    -webkit-appearance: none;

  }





button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

body{



font-family: 'lato';


}


</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->



<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
  

 
  <!-- CSS Files -->

</head>

<body class="" style="">
  
 <?php require("../confige/header/header.php");?>


<div id="main-content">










<div class="container" style="padding-top: 10vh;">







</div>













<div class="main-camp-data container">

    <div class="row">

    <div class="side-nav-menu">
    
        <div class="all-opt-name">
    <div class="head-name-opt">View By Status</div>

<div class="all-opt-con">
    
    <div class="main-opt-trg clc-for-act" type-filt='status' stat-val='10'>
<svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M2 19C2 20.6569 3.34315 22 5 22H19C20.6569 22 22 20.6569 22 19V5C22 3.34315 20.6569 2 19 2H5C3.34315 2 2 3.34315 2 5V19ZM20 19C20 19.5523 19.5523 20 19 20H5C4.44772 20 4 19.5523 4 19V5C4 4.44772 4.44772 4 5 4H10V12.0111L12.395 12.0112L14.0001 9.86419L15.6051 12.0112H18.0001L18 4H19C19.5523 4 20 4.44772 20 5V19ZM16 4H12V9.33585L14.0001 6.66046L16 9.33571V4Z" fill="currentColor"></path></svg>
<span>All</span></div>

    <div class="main-opt-trg clc-for-act" type-filt='status' stat-val='1'>

<svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.45887 2L1 6.01478L2.33826 7.50107L6.79713 3.48629L5.45887 2Z" fill="currentColor" /><path d="M11 8H13V12H16V14H11V8Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12ZM5 12C5 8.13401 8.13401 5 12 5C15.866 5 19 8.13401 19 12C19 15.866 15.866 19 12 19C8.13401 19 5 15.866 5 12Z" fill="currentColor" /><path d="M18.5411 2L23 6.01478L21.6617 7.50107L17.2029 3.48629L18.5411 2Z" fill="currentColor" /></svg>
      <span>Outgoing</span></div>
    
    <div class="main-opt-trg clc-for-act" type-filt='status' stat-val='2'>
    
    <svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M19 20H17.1717L12.7072 15.5354C12.3166 15.1449 11.6835 15.1449 11.2929 15.5354L6.82843 20L5 20V7C5 5.34315 6.34315 4 8 4H16C17.6569 4 19 5.34314 19 7V20ZM17 7C17 6.44772 16.5523 6 16 6H8C7.44772 6 7 6.44772 7 7V17L9.87873 14.1212C11.0503 12.9497 12.9498 12.9497 14.1214 14.1212L17 16.9999V7Z" fill="currentColor" /></svg>

    <span>Draft</span></div>
    
    <div class="main-opt-trg clc-for-act" type-filt='status' stat-val='0'>
    
<svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M22.775 8C22.9242 8.65461 23 9.32542 23 10H14V1C14.6746 1 15.3454 1.07584 16 1.22504C16.4923 1.33724 16.9754 1.49094 17.4442 1.68508C18.5361 2.13738 19.5282 2.80031 20.364 3.63604C21.1997 4.47177 21.8626 5.46392 22.3149 6.55585C22.5091 7.02455 22.6628 7.5077 22.775 8ZM20.7082 8C20.6397 7.77018 20.5593 7.54361 20.4672 7.32122C20.1154 6.47194 19.5998 5.70026 18.9497 5.05025C18.2997 4.40024 17.5281 3.88463 16.6788 3.53284C16.4564 3.44073 16.2298 3.36031 16 3.2918V8H20.7082Z" fill="currentColor" /><path fill-rule="evenodd" clip-rule="evenodd" d="M1 14C1 9.02944 5.02944 5 10 5C10.6746 5 11.3454 5.07584 12 5.22504V12H18.775C18.9242 12.6546 19 13.3254 19 14C19 18.9706 14.9706 23 10 23C5.02944 23 1 18.9706 1 14ZM16.8035 14H10V7.19648C6.24252 7.19648 3.19648 10.2425 3.19648 14C3.19648 17.7575 6.24252 20.8035 10 20.8035C13.7575 20.8035 16.8035 17.7575 16.8035 14Z" fill="currentColor" /></svg>

    <span>Complete</span></div>

</div>
    
    
    
        
        </div>

        <div class="part-sid-men"></div>



<div class="all-opt-name">
    <div class="head-name-opt">View By Type</div>

<div class="all-opt-con">
    
    <div class="main-opt-trg clc-for-act" type-filt='type' type-val='email'  >

<svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M3.00977 5.83789C3.00977 5.28561 3.45748 4.83789 4.00977 4.83789H20C20.5523 4.83789 21 5.28561 21 5.83789V17.1621C21 18.2667 20.1046 19.1621 19 19.1621H5C3.89543 19.1621 3 18.2667 3 17.1621V6.16211C3 6.11449 3.00333 6.06765 3.00977 6.0218V5.83789ZM5 8.06165V17.1621H19V8.06199L14.1215 12.9405C12.9499 14.1121 11.0504 14.1121 9.87885 12.9405L5 8.06165ZM6.57232 6.80554H17.428L12.7073 11.5263C12.3168 11.9168 11.6836 11.9168 11.2931 11.5263L6.57232 6.80554Z" fill="currentColor" /></svg>
     <span>Email</span></div>

    <div class="main-opt-trg clc-for-act" type-filt='type' type-val='social'>

<svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16.9307 4.01587H14.7655C14.3582 2.84239 13.2428 2 11.9307 2C10.6185 2 9.50313 2.84239 9.09581 4.01587H6.93066C5.27381 4.01587 3.93066 5.35901 3.93066 7.01587V9.21205C2.80183 9.64283 2 10.7357 2 12.0159C2 13.296 2.80183 14.3889 3.93066 14.8197V17.0159C3.93066 18.6727 5.27381 20.0159 6.93066 20.0159H9.08467C9.48247 21.2064 10.6064 22.0645 11.9307 22.0645C13.255 22.0645 14.3789 21.2064 14.7767 20.0159H16.9307C18.5875 20.0159 19.9307 18.6727 19.9307 17.0159V14.8446C21.095 14.4322 21.929 13.3214 21.929 12.0159C21.929 10.7103 21.095 9.5995 19.9307 9.18718V7.01587C19.9307 5.35901 18.5875 4.01587 16.9307 4.01587ZM5.93066 14.8687V17.0159C5.93066 17.5682 6.37838 18.0159 6.93066 18.0159H9.11902C9.54426 16.8761 10.6427 16.0645 11.9307 16.0645C13.2187 16.0645 14.3171 16.8761 14.7423 18.0159H16.9307C17.4829 18.0159 17.9307 17.5682 17.9307 17.0159V14.8458C16.7646 14.4344 15.929 13.3227 15.929 12.0159C15.929 10.709 16.7646 9.59732 17.9307 9.18597V7.01587C17.9307 6.46358 17.4829 6.01587 16.9307 6.01587H14.7543C14.338 7.17276 13.2309 8 11.9307 8C10.6304 8 9.52331 7.17276 9.10703 6.01587H6.93066C6.37838 6.01587 5.93066 6.46358 5.93066 7.01587V9.16302C7.13193 9.55465 8 10.6839 8 12.0159C8 13.3479 7.13193 14.4771 5.93066 14.8687Z" fill="currentColor" /></svg>
     <span>Social Post</span></div>
    
    <div class="main-opt-trg clc-for-act" type-filt='type' type-val='survey'>
<svg class="svg-ico-of-dt" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M19 4H5C4.44771 4 4 4.44772 4 5V19C4 19.5523 4.44772 20 5 20H19C19.5523 20 20 19.5523 20 19V5C20 4.44771 19.5523 4 19 4ZM5 2C3.34315 2 2 3.34315 2 5V19C2 20.6569 3.34315 22 5 22H19C20.6569 22 22 20.6569 22 19V5C22 3.34315 20.6569 2 19 2H5Z" fill="currentColor" /><path d="M11 7H13V17H11V7Z" fill="currentColor" /><path d="M15 13H17V17H15V13Z" fill="currentColor" /><path d="M7 10H9V17H7V10Z" fill="currentColor" /></svg>

      <span>Surveys</span></div>
    
  <button type="button" class="btn-theme-dsg com-for-lnk btn-act-load" data-for-serv="0" data-target-link="https://campign.auftera.com/campigns/" id="crt-new" style="height: 40px;text-align:left;margin-top: 30px;">Create Campign<img src="https://res.cloudinary.com/heptera/image/upload/v1618934560/campign/schedule_send_white_24dp_ajen4i.svg" style="
    padding-left: 20px;float:right;
"></button>  







<button type="button" class="btn-theme-dsg com-for-lnk btn-act-load" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/" id="crt-new-soc-camp-all" style="text-align:left;height: 40px;background-color: #2a7288;">Social Post<img src="https://res.cloudinary.com/heptera/image/upload/v1618981749/campign/groups_white_24dp_iq6ork.svg" style="
  padding-left: 20px;float:right;
"></button>


</div>
    
    
    
        
        </div>








    
    </div>
    
    
    
    <div class="main-res-con">
    
    <div class='head-of-main-con'>
           <div class="dropdown" style="
    width: 50%;
">
  <input class="ip-srch" id='srch_ip_in_camp' data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  <div class="dropdown-menu" id='opt-of-srch-fld' aria-labelledby="dropdownMenuButton" x-placement="bottom-start" style="position: absolute; will-change: transform; width: 100%; top: 0px; left: 0px; transform: translate3d(0px, 40px, 0px);">
    <a class="dropdown-item clc-for-act" type-filt='type' type-val='email' href="javascript:void(0);"><i class="fal fa-envelope"></i>Email</a>
    <a class="dropdown-item clc-for-act" type-filt='type' type-val='social' href="javascript:void(0);"><i class="fal fa-hashtag"></i>Social Post</a>
    <a class="dropdown-item clc-for-act" type-filt='type' type-val='survey' href="javascript:void(0);"><i class="fal fa-poll-h"></i>Survey</a>
  </div>
</div>




    </div>




<div id="all-res-of-query">


</div>



</div>





    
    </div>
    
    
    </div>

</div>














</div>







<div class="modal-2" data-modal="modal-del-camp" id='modal-del-camp'>
  <article class="content-wrapper">
     <button type="button" class="close-2">
          
        </button>
    
    

<div class="head-line-of-mdl">
    <h4>Are You Sure to Delete This Campign Permanently. </h4>

</div>

    <div class="content" style="
">
   <p>Once Delete this campign We Not Able To Send And seduled any post or Email.please, review...</p>
   </div>


<div class="btn-con-del-camp">

    <button class="btn-theme-dsg " id='del_conf_btn' style="">Yes,Delete Campign</button>
    
    <button class="btn-theme-dsg  del_mdl_cls" style="background:white;color:#350835;border:1px solid #350835;">Cancel,Keep It Campign</button>

    
</div>


   
 
  </article>
</div>


<div class="modal-2" data-modal="del_temp_modal" id="mdl-del-temp">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Copy Campign</h5>
        <button type="button" class="close-2" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times-circle"></i></span>
        </button>
      </div>
      <div class="modal-body">
        <label style="padding-top:10px;font-weight:450;color:black;letter-spacing:0.6px;">Whish To Copy Campign</label>
 <div id="cp_camp_name" style="color:red;font-weight:700;">progress-test</div>
      </div>
      <div class="modal-footer">
        
        <button type="button" class="btn-theme-dsg" id="cnfrm-btn-cp">Copy Campign</button>
      </div>
    </div>
  </div>
</div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
<script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968180/dashboard-js/argon-dashboard1_alwe1m.js"></script>




  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script>


str_of_glob_append='';

data_main_camp=[];

camp_cp_id='';



$(document).ready(function(){
  
 
 init_all_camp_data_name();     
 
});


function init_all_camp_data_name(){



str_of_glob_append="";

$("#all-res-of-query").empty();

$('#all-res-of-query').html('<div class="main-load-con" style=" width:100%;text-align:center; "><div class="cp-spinner cp-round"></div></div>');

    $.ajax({
    url : "./ajaxfile/get_all_type_camp.php",
    type: "POST"
  }).done(function(response){ //

   

data_main_camp=JSON.parse(response);

data_of_email_camp=data_main_camp['email_camp'];

data_of_soc_camp=data_main_camp['soc_camp'];

init_loop_email_camp_lst(data_of_email_camp,10,'null');


console.log(data_of_soc_camp);

init_loop_soc_camp_lst(data_of_soc_camp,10,'null');



  append_str_of_main_camp();

        
  });





}



function init_loop_email_camp_lst(data,filt_opt,srch_opt){


for (var i = 0; i < data.length; i++) {
  

if(filt_opt<5){


if(data[i]['flg_send']==filt_opt){



append_str_of_email_camp(data[i]);

}



continue;
}





if(srch_opt!='null'){



if(data[i]['camp_name'].split('^')[1].search(srch_opt)!=-1){



append_str_of_email_camp(data[i]);

}

  
continue;
}




append_str_of_email_camp(data[i]);


};

}


function init_loop_soc_camp_lst(data,filt_opt,srch_opt){


for (var i = 0; i < data.length; i++) {
  
if(filt_opt<5){


if(data[i]['flg_send']==filt_opt){

append_str_of_soc_camp(data[i]);

}


continue;
}



if(srch_opt!='null'){

if(atob(data[i]['post_name'].split('^')[1]).search(srch_opt)!=-1){


append_str_of_soc_camp(data[i]);

}

  
continue;
}

append_str_of_soc_camp(data[i]);




};

}



function append_str_of_soc_camp(data){


name_of_camp_dis=atob(data['post_name'].split('^')[1]);


date_of_camp= new Date(Date.parse(data['date_time']));


status_of_camp=get_status_of_camp(data['flg_send']);


act_id=data['post_name'];


str_of_glob_append+='<div class="main-con-of-camp-name"> <div class="main-name-camp"> <div class="main-name-sel-one-camp"> <span class="ico-of-camp-dis"><i class="fad fa-hashtag ico-of-camp-dis"></i></span> </div> <div class="name-hold-of-camp"> <span class="txt-name-of-camp"> '+name_of_camp_dis+'</span><br> <span class="text-type-of-camp"> Post * By You </span> <br> <div class="text-date-of-camp"> Edited <strong>'+date_of_camp+'</strong> by you </div> </div> <div class="get-stat-of-camp"> <span class="badge badge-pill badge-dark">'+status_of_camp+'</span> </div> <div class="blck_spc"> </div> <div class="init-opt-for-camp"> <div class="row">   <button class="without-back-btn opn_del_mdl" type_del="social" id="'+act_id+'" data-modal-trigger="modal-del-camp" ><img   aria-hidden="true" src="https://res.cloudinary.com/heptera/image/upload/v1604036680/icon-svg/trash-empty_os5slt.svg" height="20"></button> </div> </div> </div> </div>';





}






function act_btn_shw_des(status,name_of_camp_dis,act_id,camp_id){

	if(status>1){

	str_ret='<div class="init-opt-for-camp"> <div class="row"> <button class="without-back-btn red_fun_of_link" red-lnk="../?camp_id='+camp_id+'" ><img src="https://res.cloudinary.com/heptera/image/upload/v1618934875/campign/edit_black_24dp_fhwu0s.svg"  height="20"></button> <button class="without-back-btn" data-modal-trigger="del_temp_modal" data-camp-name="'+name_of_camp_dis+'" id="cp-camp-new-nw"  data-camp-id="'+act_id+'"><img  src="https://res.cloudinary.com/heptera/image/upload/v1618934960/campign/content_copy_black_24dp_cphx3w.svg" height="20"></button> <button class="without-back-btn opn_del_mdl" id="'+act_id+'" data-modal-trigger="modal-del-camp"><img    aria-hidden="true" src="https://res.cloudinary.com/heptera/image/upload/v1618934993/campign/delete_black_24dp_qp0c9r.svg" height="20"></button> </div> </div>';

}else{

	str_ret='<div class="init-opt-for-camp"> <div class="row">  <button class="without-back-btn opn_del_mdl" id="'+act_id+'" data-modal-trigger="modal-del-camp"><img    aria-hidden="true" src="https://res.cloudinary.com/heptera/image/upload/v1604036680/icon-svg/trash-empty_os5slt.svg" height="20"></button> </div> </div>';

}

return str_ret;

}










function append_str_of_email_camp(data){

console.log(data);


name_of_camp_dis=data['camp_name'].split('^')[1];


date_of_camp= new Date(Date.parse(data['camp_shed_time']));


status_of_camp=get_status_of_camp(data['flg_send']);


act_id=data['camp_contact_id'];



str_of_act=act_btn_shw_des(data['flg_send'],name_of_camp_dis,act_id,data['camp_name']);


str_of_glob_append+='<div class="main-con-of-camp-name"> <div class="main-name-camp"> <div class="main-name-sel-one-camp"> <span class="ico-of-camp-dis"><i class="fal fa-envelope-open-text ico-of-camp-dis" aria-hidden="true" style="  "></i></span> </div> <div class="name-hold-of-camp"> <span class="txt-name-of-camp"> '+name_of_camp_dis+'</span><br> <span class="text-type-of-camp"> Email * By You </span> <br> <div class="text-date-of-camp"> Edited <strong>'+date_of_camp+'</strong> by you </div> </div> <div class="get-stat-of-camp"> <span class="badge badge-pill badge-dark">'+status_of_camp+'</span> </div> <div class="blck_spc"> </div>'+str_of_act+' </div> </div>';




}



function get_status_of_camp(flg){


  if(flg<'1'){

    return 'completed';

  }else if(flg<'2'){

    return 'Outgoing';
  }else if(flg<'3'){

return 'Draft';

  }
}







$(document).on('click','.clc-for-act',function(){


str_of_glob_append='';

type_of_filt=$(this).attr('type-filt');


if(type_of_filt=='status'){


filt_val=$(this).attr('stat-val');

console.log(filt_val);
  

  init_loop_email_camp_lst(data_main_camp['email_camp'],filt_val,'null');

init_loop_soc_camp_lst(data_main_camp['soc_camp'],filt_val,'null');



}else if(type_of_filt=='type'){


filt_val=$(this).attr('type-val');


filt_data_by_type(filt_val);


}


append_str_of_main_camp();


})



function filt_data_by_type(flg_type){


if(flg_type=='email'){


  init_loop_email_camp_lst(data_main_camp['email_camp'],10,'null');


}else if(flg_type=='social'){

init_loop_soc_camp_lst(data_main_camp['soc_camp'],10,'null');

}

}

$(document).on('change','#srch_ip_in_camp',function(){

srch_val=$(this).val();


if(srch_val.length==0){

$("#opt-of-srch-fld").children('#srch_custom_txt').remove();

}else{


$("#opt-of-srch-fld").prepend('<a class="dropdown-item " id="srch_custom_txt" src-val="'+srch_val+'" href="javascript:void(0);">'+srch_val+'</a>');



}




});



$(document).on('click','#srch_custom_txt',function(){



srch_val=$(this).attr('src-val');


  str_of_glob_append='';






init_loop_email_camp_lst(data_main_camp['email_camp'],10,srch_val);


init_loop_soc_camp_lst(data_main_camp['soc_camp'],10,srch_val);





append_str_of_main_camp();



})



function append_str_of_main_camp(){

if(str_of_glob_append==''){

str_of_glob_append='<div class="not-fd-con"> <img class="not-fd-camp" src="https://res.cloudinary.com/heptera/image/upload/v1600940446/campign/3081629_aev4cv.jpg"><p class="txt-of-not-fd">You have not any template for particular choice.</p><button type="button" class="btn-theme-dsg com-for-lnk btn-act-load" data-for-serv="0" data-target-link="https://campign.auftera.com/campigns/" id="crt-new" style="height: 40px;text-align:left;margin-top: 30px;width: 200px;">Create Campign<img src="https://res.cloudinary.com/heptera/image/upload/v1618934560/campign/schedule_send_white_24dp_ajen4i.svg" style="padding-left: 20px;float:right;"></button></div>';

}


$("#all-res-of-query").html(str_of_glob_append);

}





$(document).on('click','.del_soc_camp',function(){




$(this).prop('disabled', true);


$(this).html('<div class="cp-spinner cp-round"></div>');


del_soc_camp($(this).attr('id'));


})



$(document).on('click','.del_email_camp',function(){



$(this).prop('disabled', true);


$(this).html('<div class="cp-spinner cp-round"></div>');


del_email_camp($(this).attr('id'));







})

$(document).on('click','.opn_del_mdl',function(){

del_type='del_email_camp';

if($(this).attr('type_del')=='social'){

  del_type='del_soc_camp';

}

$("#del_conf_btn").addClass(del_type);

$("#del_conf_btn").attr('id',$(this).attr('id'));

modalEvent(this);


})









function modalEvent(button) {

  
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    
    
    const close = modal.querySelector('.close-2');

    close.addEventListener('click', () => modal.classList.remove('open'));
    

    modal.classList.toggle('open');
  
  
}


$(document).on('click','.del_mdl_cls',function(){

close_mdl_del();

})



function close_mdl_del(){

$("#modal-del-camp").removeClass('open');




}





function del_soc_camp(passed_name){



$.ajax({
  type: "POST",
  url: "./ajaxfile/del_soc_camp.php",
  data : {camp_name:passed_name}
 
}).done(function(response1) {

close_mdl_del();


$("#all-res-of-query").empty();

init_all_camp_data_name();

       
       init_btn_fr_del_ele_camp();

});




}




function del_email_camp(passed_name){



$.ajax({
  type: "POST",
  url: "./ajaxfile/del_email_camp.php",
  data : {camp_name:passed_name}
 
}).done(function(response1) {

close_mdl_del();

$("#all-res-of-query").empty();

console.log(response1);

//init_all_camp_data_name();


//init_btn_fr_del_ele_camp();

       

});




}


function init_btn_fr_del_ele_camp(){




$("#cnfrm-btn-cp").prop('disabled', false);


$("#cnfrm-btn-cp").html('Yes,Delete Campign');



}


$(document).on('click','#cp-camp-new-nw',function(){


$("#cp_camp_name").html($(this).attr('data-camp-name'));


camp_cp_id=$(this).attr("data-camp-id");

console.log(camp_cp_id);
modalEvent(this);

})


$(document).on('click','#cnfrm-btn-cp',function(){


cp_email_camp_new(camp_cp_id);


})





function cp_email_camp_new(cpID){


$("#cnfrm-btn-cp").prop('disabled', true);


$("#cnfrm-btn-cp").html('<div class="cp-spinner cp-round"></div>');



$.ajax({
  type: "POST",
  url: "./ajaxfile/cp_of_email_camp.php",
  data : {camp_id:cpID}
 
}).done(function(response1) {



window.location.href="../../campigns/?camp_id="+response1;
       

});





}



$(document).on("click",".red_fun_of_link",function(){



window.location.href=$(this).attr("red-lnk");


})









</script>
  
  
</body>

<script type="text/javascript" src="../jsfile/stickyheader4.js">

</script>



</html>

