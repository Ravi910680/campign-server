<?php


session_start();
require("../../confige/social_post_confige.php");


$data=$_POST;

$camp_name_req=$data['camp_name'];

function del_camp_all($conn,$del_field,$val,$tbl){



$del_query="DELETE FROM ".$tbl." WHERE ".$del_field."='".$val."'";

if ($conn->query($del_query) === TRUE) {
  return 1;
} else {
  return 0;
}



}



if(del_camp_all($social_post_conn,'post_name',$camp_name_req,'camp_soc_hy')){


if(del_camp_all($social_post_conn,'camp_name',$camp_name_req,'post_que_data')){

if(del_camp_all($social_post_conn,'camp_id',$camp_name_req,'post_data_url')){


echo 1;


}




}


}



?>