<?php
require("../../confige/camp_confige.php");
session_start();

$id=$_SESSION['id'];





$camp_id=$_POST['camp_id'];


function get_curr_time(){


$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);

return $late_time;



}


function crt_up_fld_str($arr,$val_fld){

$res_str="";

foreach ($arr as $key => $value) {
	
	$res_str.=$value."='".$val_fld."',";


}

$res_str=substr($res_str, 0, -1);

return $res_str;


}

function crt_cp_tbl($conn,$camp_name,$camp_id,$fld_tp,$arr_of_up_val,$tbl_name){

$str_up_val="";




$crt_tbl="CREATE TEMPORARY TABLE temporary_table AS SELECT * FROM ".$tbl_name." WHERE ".$fld_tp."='".$camp_id."' ";


$conn->query($crt_tbl);



print_r($conn->error);

$str_up_val=crt_up_fld_str($arr_of_up_val,$camp_name);


try{
$up_date_fld="UPDATE temporary_table SET ".$str_up_val.",flg_send=3,camp_shed_time=''";

$conn->query($up_date_fld);

throw new Exception();

}

catch(Exception $e){

$up_date_fld="UPDATE temporary_table SET ".$str_up_val;


$conn->query($up_date_fld);

}

$isrt_of_camp="INSERT INTO ".$tbl_name." SELECT * FROM temporary_table";


$conn->query($isrt_of_camp);

$drp_tbl='DROP TEMPORARY TABLE temporary_table';


$conn->query($drp_tbl);
}


$camp_con_id=$id."^".get_curr_time();


crt_cp_tbl($camp_name_conn,$camp_con_id,$camp_id,"camp_contact_id",['camp_name','camp_contact_id','camp_content_data'],'camp_name_tbl');

crt_cp_tbl($camp_name_conn,$camp_con_id,$camp_id,"camp_id",['camp_id'],'camp_content_tbl');


print_r($camp_con_id);




?>
