<?php


session_start();
require("../../confige/camp_confige.php");

require("../../confige/contact_confige.php");








$servername = "campign.chmwcgvoxwwi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="camp_analysis";




$camp_ana = mysqli_connect($servername, $username, $password,$db);


$db_url=mysqli_connect($servername, $username, $password,"camp_url_data");




if ( $_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST) ) {
    $_POST = json_decode(file_get_contents('php://input'), true);
}





$data=$_POST;

$camp_name_req=$data['camp_name'];

function del_camp_all($conn,$del_field,$val,$tbl){



$del_query="DELETE FROM ".$tbl." WHERE ".$del_field."='".$val."'";

if ($conn->query($del_query) === TRUE) {
  return 1;
} else {
  return 0;
}



}


function select_query($conn,$sel_query){


	$ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    

    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}




$res_arr=array("status"=>0,"message"=>"Something Wen't Wrong");





if(del_camp_all($camp_name_conn,'camp_contact_id',$camp_name_req,'camp_name_tbl')){


	$sel_temp_name="Select * from camp_content_tbl where camp_id='$camp_name_req'";
	$temp_data=select_query($camp_name_conn,$sel_temp_name)[0]['temp_id'];

	
	unlink("../../camp_temp/".$camp_name_req."#".$temp_data.".php");
if(del_camp_all($camp_name_conn,'camp_id',$camp_name_req,'camp_content_tbl')){

	$sel_lst_qer="select list_id from camp_contact_tbl where camp_con_id='".$camp_name_req."'";
	$res=$camp_name_conn->query($sel_lst_qer);












	while($row = $res->fetch_assoc()) {

$lst_id=$row['list_id'];
$rem_query="alter table `".$lst_id."` drop column `".$camp_name_req."`";
$conn3->query($rem_query);


$tbl_name_del=$camp_name_req."#".$lst_id;

$del_ana_tbl="drop table `".$tbl_name_del."`";
$camp_ana->query($del_ana_tbl);

$url_del="DELETE FROM temp_url_data_crw WHERE url_id LIKE '".$camp_name_req."%'";
$db_url->query($url_del);

  }




if(del_camp_all($camp_name_conn,'camp_con_id',$camp_name_req,'camp_contact_tbl')){


$res_arr['status']=1;
$res_arr['message']="Campign Deleted SuccessFully";

}




}


}


echo json_encode($res_arr);


?>
