<?php
session_start();



function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}

cors();



if(isset($_POST['usr_id'])){

$id=$_POST['usr_id'];

}else{

$id=$_SESSION['id'];

}
require("../../confige/contact_confige.php");

require("../../confige/camp_confige.php");

require("../../confige/camp_analysis.php");





$camp_id=$_POST['camp_id'];

$date = $_POST['time_data']; 




function get_curr_time($tz){



$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);

return $late_time;



}

function conv_loc_to_utc($date,$tz){

$given = new DateTime($date, new DateTimeZone($tz));
$given->setTimezone(new DateTimeZone("UTC"));
$output = $given->format("Y-m-d H:i:s"); 

return $output;
}


$lst_id=json_decode($_POST['lst_dt']);


$date = strtotime($date); 


$sel_time_for_camp= date('Y-m-d H:i:s', $date);


 $get_tz_usr=file_get_contents("https://account.auftera.com/account/main/settings/ajaxfile/get_tz_of_usr.php?id=".$id);



$tz=json_decode($get_tz_usr)[0]->time_zone;





if(get_curr_time($tz)<strtotime($sel_time_for_camp)){


$camp_utc_dt=conv_loc_to_utc($sel_time_for_camp,$tz);

$camp_con_id=1;

$camp_id=trim($camp_id);
$isrt_camp_name="update camp_name_tbl set camp_shed_time='$camp_utc_dt',flg_send='2'  where camp_contact_id='".$camp_id."'";



if ($camp_name_conn->query($isrt_camp_name) === TRUE) {
 

foreach ($lst_id as $key => $value) {


$ana_tbl_name=$camp_id."#".$value;

$tblsql = "CREATE TABLE `".$ana_tbl_name."`(
     
     id varchar(10) NOT NULL,
     act varchar(10) NOT NULL,
     cnt varchar(4),
     act_date datetime,
     reg varchar(12),     PRIMARY KEY(id,act)         
        )";





if($camp_ana_conn->query($tblsql)==TRUE){




	$crt_new_col_in_lst="Alter table `$value` add `$camp_id` int(2)  DEFAULT '0' ";
	$res_add_col=$conn3->query($crt_new_col_in_lst);





}

}


 echo 1;

} else {
  echo $camp_name_conn->error;
}

}else{


	echo "Select Valid Time Please";



}
?>
