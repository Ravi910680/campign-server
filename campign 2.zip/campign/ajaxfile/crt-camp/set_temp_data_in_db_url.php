<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 */
require("../../confige/save_url_db_confige.php");




function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}

cors();


function getValidUrlsFrompage($html)
  {
    $links_ret =array();

//Create a new DOM document
$dom = new DOMDocument;

//Parse the HTML. The @ is used to suppress any parsing errors
//that will be thrown if the $html string isn't valid XHTML.
@$dom->loadHTML($html);

//Get all links. You could also use any other tag name here,
//like 'img' or 'table', to extract other tags.
$links = $dom->getElementsByTagName('a');


//Iterate over the extracted links and display their URLs
foreach ($links as $link){
    //Extract and show the "href" attribute.

$url_dt=$link->getAttribute('href');



if (filter_var($url_dt, FILTER_VALIDATE_URL) !=FALSE) {

    array_push($links_ret,$url_dt );

}else if(explode("#",$url_dt)[1]=="auftera"){

	array_push($links_ret,$url_dt);

}


}

    return $links_ret;


}


function getInbetweenStrings($start, $end, $str){
    $matches = array();
    $regex = "/$start([a-zA-Z0-9_]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1];
}


function minifier($code) {
    $search = array(

        // Remove whitespaces after tags
        '/\>[^\S ]+/s',

        // Remove whitespaces before tags
        '/[^\S ]+\</s',

        // Remove multiple whitespace sequences
        '/(\s)+/s',

        // Removes comments
        '/<!--(.|\s)*?-->/'
    );
    $replace = array('>', '<', '\\1');
    $code = preg_replace($search, $replace, $code);
    return $code;
}

function isrt_url_data_in_db($conn,$url){



$isrt_query_db="insert into temp_url_data_crw (url) value('$url')";

$data_res=$conn->query($isrt_query_db);

$sel_url_data="select * from  temp_url_data_crw where url='$url'";

$data_get=$conn->query($sel_url_data);




$result=$data_get->fetch_assoc();

return $result['url_id'];




}

function url_get_contents ($Url) {
    if (!function_exists('curl_init')){
        die('CURL is not installed!');
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $Url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

$camp_name=$_POST['camp_id'];

$subject_line=$_POST['subject'];

$un_red_link=$_POST['red_url_un'];


$str_arr = getInbetweenStrings('{{', '}}', $subject_line);


$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {


$subject_line=str_replace("{{".$value."}}","<?php echo \$_GET['".$value."'];?>",$subject_line);


}



$camp_temp_name=$_POST['temp_id'];

$camp_name=trim($camp_name);




if(isset($_POST['old_temp_name'])){

unlink($camp_name."#".$_POST['old_temp_name'].".php");

}
$camp_save_dt_name=$camp_name."#".$camp_temp_name.".php";

$flg_of_sub_btn=1;
$flg_of_open_brws_btn=1;

$html = url_get_contents("https://template.auftera.com/template/crt-template/crtedtemp/".$camp_temp_name.".html");


$links = getValidUrlsFrompage($html);

foreach ($links as $key => $value) {

if($value=="#auftera#unsubscribe"){

$flg_of_sub_btn=1;

$create_red_url="href=\"https://contact.auftera.com/contact/unsubscribe/?con_id=<?php echo \$_GET['con_id'];?>&lst_name=<?php echo \$_GET['lst_name'];?>&red_url=".$un_red_link."\"";

$value="href=\"".$value."\"";

$html=str_replace($value,$create_red_url,$html);

}else if($value=="#auftera#open_in_browser"){

$flg_of_open_brws_btn=1;
/*
$create_red_url="Href=\"https://campign.auftera.com/campign/open_in_browser/?con_id=<?php echo \$_GET['con_id'];?>&lst_name=<?php echo \$_GET['lst_name'];?>&save_temp_name=".urlencode($camp_save_dt_name)."\"";
*/


$create_red_url="Href=\"https://template.auftera.com/template/crt-template/crtedtemp/842298392%5eMTY0MTU1MzQ4OA==.html\"";

$value="href=\"".$value."\"";

$html=str_replace($value,$create_red_url,$html);





}else{


	 if(count(getInbetweenStrings('{{', '}}', $value))==0){

	$value_isrt=$value;



$url_id=isrt_url_data_in_db($url_temp_camp_conn ,$value_isrt);


$create_red_url="href=\"http://track-email.auftera.com/email/click/<?php echo \$_GET['con_id'];?>/<?php echo \$_GET['lst_name'];?>/".$camp_name."/".$url_id."\"";


$value="href=\"".$value."\"";

$html=str_replace($value,$create_red_url,$html);

}


}

}



$str_arr = getInbetweenStrings('{{', '}}', $html);


$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {


$html=str_replace("{{".$value."}}","<?php echo \$_GET['".$value."'];?>",$html);


}



$myfile = fopen("../../camp_temp/".$camp_save_dt_name, "w") or die("Unable to open file!");
$txt = $html;

$open_res_img_tag=$txt;


$open_res_img_tag="<img src='http://track-email.auftera.com/email/open/<?php echo \$_GET['con_id'];?>/<?php echo \$_GET['lst_name'];?>/".$camp_name."' id='track-email-auftera-918758'>".$txt;



$str_of_save="{'subject_line':'".$subject_line."','content_for_send':'".minifier($open_res_img_tag)."'}";

$arr_of_save=array('subject_line'=>$subject_line,'content_for_send'=>minifier($open_res_img_tag));

fwrite($myfile,json_encode($arr_of_save));
fclose($myfile);



$res_arr=array("status"=>0,"message"=>"");


if($flg_of_sub_btn==1){
if($flg_of_open_brws_btn==1){

$res_arr['status']=1;
$res_arr['message']="Template Condition Is good";

}else{
$res_arr['status']=0;
$res_arr['message']="Add open Browser Button In template";

}

}else{

$res_arr['status']=0;
$res_arr['message']="Add Unsubscribe Button";

}




echo json_encode($res_arr);









?>
