<?php
session_start();



require("../../confige/camp_confige.php");



function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}

cors();

if(isset($_POST['usr_id'])){

$id=$_POST['usr_id'];
}else{
$id=$_SESSION['id'];
}

function get_curr_time(){


$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');


$late_time=strtotime($today_formatted);

return $late_time;



}






$camp_name=$_POST['camp_name'];


$old_name=$_POST['old_name'];




$camp_name=$id."^".$camp_name;



if($old_name=="newcampigns"){

$camp_con_id=$id."^".get_curr_time();



$isrt_camp_name="insert into camp_name_tbl VALUES ('$id','$camp_name','$camp_con_id','$camp_con_id','','3')";


}else{

	$old_name=$id."^".$old_name;

$camp_con_id=1;

$isrt_camp_name="update camp_name_tbl set camp_name='$camp_name' where camp_name='$old_name'";


}





if ($camp_name_conn->query($isrt_camp_name) === TRUE) {



	echo json_encode(array("status"=>1,"message"=>$camp_con_id));





} else {
   echo json_encode(array("status"=>0,"message"=>"Campign Present with this name"));
}

?>

