<?php


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require("../../confige/camp_confige.php");

#mysql_set_charset('utf8',$camp_name_conn);

$camp_name_conn->set_charset("utf8");
function hit_query_php($conn,$sql){


if ($conn->query($sql) === TRUE) {
  return 1;
} else {
  return $conn->error;
}



}


function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}

cors();



$mail_temp=$_POST['temp_name'];

$mail_sub=str_replace("'","\'",$_POST['mail_sub']);

$mail_pre=str_replace("'","\'",$_POST['mail_pre']);

$sender_id_send=$_POST['sender_id'];

$smtp_id=$_POST['smtp_id'];

$con_id_dt=$_POST['con_id'];

$reply_id=$_POST['reply_id'];

$con_id_dt=trim($con_id_dt);

$del_old_lst="delete from camp_content_tbl where camp_id='".$con_id_dt."'";

$res_del=hit_query_php($camp_name_conn,$del_old_lst);




$isrt_of_con_data="insert into camp_content_tbl values('$mail_temp','$mail_sub','$mail_pre','$sender_id_send','$smtp_id','$con_id_dt','$reply_id')";


$res_del=hit_query_php($camp_name_conn,$isrt_of_con_data);

echo $res_del;







?>
