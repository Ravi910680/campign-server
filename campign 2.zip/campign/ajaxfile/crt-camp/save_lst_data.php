<?php


require("../../confige/camp_confige.php");



function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}

cors();



function hit_query_php($conn,$sql){


if ($conn->query($sql) === TRUE) {
  return 1;
} else {
  echo $conn->error;
}



}


$flg_suc=1;




$merg_fld=$_POST['merge_fld'];

$list_dt=$_POST['list_data'];

$filt_dt=$_POST['filt_opt'];


$con_id_dt=$_POST['con_id'];

$qued_data=$_POST['que_data'];

$ptr_of_reach=$_POST['ptr'];

$del_old_lst="delete from camp_contact_tbl where camp_con_id='".$con_id_dt."'";

$res_del=hit_query_php($camp_name_conn,$del_old_lst);

$list_dt=json_decode($list_dt);




$con_id_dt=trim($con_id_dt);

foreach ($list_dt as $key => $value) {
	$isrt_in_con_tbl="insert into camp_contact_tbl values('$con_id_dt','$value','$filt_dt','$merg_fld','3','$qued_data','$ptr_of_reach')";
	$res_of_qur= hit_query_php($camp_name_conn,$isrt_in_con_tbl);

	if($res_of_qur==0){
$flg_suc=0;

	}
}

echo $flg_suc;

?>

