<?php
session_start();

require("../../confige/segment_confige.php");





$arr_of_dt=array();

$id=$_SESSION['id'];


$seg_sel_query="select * from seg_list where id='$id'";


$result =$seg_conn->query($seg_sel_query);

if($result->num_rows>0){

while($row = $result->fetch_assoc()) {





    $loc_arr=array();



$loc_arr['label']=$row['seg_name'];
$loc_arr['value']=$row['unq_id'];

 
array_push($arr_of_dt, $loc_arr);


  }

  echo json_encode($arr_of_dt);
}else{

}
?>
