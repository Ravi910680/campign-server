<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require("../../confige/camp_confige.php");



function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
        return $conn->error;
}


}


$flg_att=0;

$camp_id=$_POST['camp_id'];
$attach_data=$_POST['data_of_attach'];

$del_query="Delete from `attachment` where camp_id='$camp_id'";

isrt_query_db($camp_name_conn,$del_query);

foreach (json_decode($attach_data) as $key => $value) {

$url_data=$value->url;
$name_of_attach=$value->name;

$isrt_query="insert into `attachment` VALUES ('$camp_id','$url_data','$name_of_attach')";


$flg_att=$flg_att+isrt_query_db($camp_name_conn,$isrt_query);
}





echo json_encode(array("status"=>1,"message"=>$flg_att));

 ?>

