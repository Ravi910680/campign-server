<?php
require("../../confige/camp_confige.php");
$get_camp_id=$_GET['camp_id'];


$sel_data_temp_ver="select * from camp_name_tbl where camp_name='".$get_camp_id."'";

$res=$camp_name_conn->query($sel_data_temp_ver);

$res_stat=array("status"=>0,"message"=>"");

if($res->num_rows > 0){

while($row = $res->fetch_assoc()) {

if($row['flg_send']=='2'){
  
  $res_stat["status"]=0;
  $res_stat["message"]="./pages/crt_camp_exist/?camp_id=".$get_camp_id;

}else{

	$res_stat["status"]=1;
  $res_stat["message"]=$get_camp_id;

}
   
  }

}else{

 $res_stat["status"]=0;
  $res_stat["message"]="./pages/camp_not_fd/";


}

echo json_encode($res_stat);

?>
