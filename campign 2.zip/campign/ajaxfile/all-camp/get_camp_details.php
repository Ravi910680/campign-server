<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require("../../confige/camp_confige.php");



function select_query($conn,$sel_query){


        $ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

function get_name_of_filt($data){


$data=json_decode($data);

$tp_code=$data->name;

if($tp_code=="all_sub"){
  return "All Contact";
}else if($tp_code=="segment"){

  return "Segment";
}else if($tp_code=="tag"){
  return "tag";
}


}

function get_que_data_of_camp($data){

$ret_arr=array();
$data_of_qu=json_decode($data);
$ret_arr['type_of_campign']=$data_of_qu->type_seq;
$ret_arr['length_of_part']=count($data_of_qu->arr_of_att);


return $ret_arr;
}

$camp_id=$_GET['camp_id'];

$res_arr=array();

$sel_name_data="select * from `camp_name_tbl` where camp_contact_id='$camp_id'";


$main_name_data=select_query($camp_name_conn,$sel_name_data)[0];
$res_arr['name']=explode("^",$main_name_data['camp_name'])[1];
$res_arr['sheduled']=$main_name_data['camp_shed_time']."(UTC)";
$res_arr['status']="success";


$sel_con_detail="select * from `camp_contact_tbl` where camp_con_id='$camp_id'";
$main_name_data=select_query($camp_name_conn,$sel_con_detail);



$ret_of_list_name=array();

foreach ($main_name_data as $key => $value) {

$filt_data_of_camp=$value['filt_data'];
$que_data=$value['que_data'];
array_push($ret_of_list_name,base64_decode(explode("^",$value['list_id'])[1]));

}


$res_arr['contact']['list_data']=$ret_of_list_name;

$res_arr['contact']['filter_data']=get_name_of_filt($filt_data_of_camp);

$res_arr['contact']['que']=get_que_data_of_camp($que_data);

$sel_con_detail="select * from `camp_content_tbl` where camp_id='$camp_id'";
$main_name_data=select_query($camp_name_conn,$sel_con_detail);

$content_data=array();

foreach ($main_name_data as $key => $value) {

$send_data_enco=json_decode($value['sender_id']);

$loc_arr=array("template"=>base64_decode(explode("^",$value['temp_id'])[1]),"template_id"=>$value['temp_id'],"subject_line"=>$value['sub_fld'],"sender_name"=>$send_data_enco->sender_name);

array_push($content_data,$loc_arr);
}

$res_arr['content']=$content_data;


print_r(json_encode($res_arr));

 ?>

