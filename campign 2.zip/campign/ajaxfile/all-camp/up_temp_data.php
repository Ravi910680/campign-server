<?php


require("../../confige/camp_confige.php");



function isrt_query_db($conn,$isrt_query){


if($conn->query($isrt_query)){

return 1;

}else{
        return $conn->error;
}


}


$data_up=json_decode($_POST['up_data']);
$camp_id=$_POST['camp_con_id'];

$str_of_up="";
foreach ($data_up as $key => $value) {

$str_of_up.=$key."='".$value."',";


}

$str_of_up=substr($str_of_up, 0, -1);

$up_query="update `camp_content_tbl` set ".$str_of_up." where camp_id='$camp_id'";

echo isrt_query_db($camp_name_conn,$up_query);



?>
