<?php

require '../ab_testing/ajaxfile/lib_auftera.php';
session_start();

$email=$_SESSION['email'];

$temp_id=$_POST['temp_id'];
$sub_txt=$_POST['sub_mail'];

$send_arr_body=array (
  'to-name' => 'admin',
'from' =>'ravigorasiya65@gmail.com',  
  'from-name' => 'auftera',
  'subject' => $sub_txt,
  'content' => $temp_id,
  'tp_dir' => 'direct',
   
);


echo auft_req_api('POST','send/497889959^dXNlcl9saXN0/template/email/'.$email.'/',$send_arr_body,'5a5h5g83kijj1d0903nfh3d9');
?>
