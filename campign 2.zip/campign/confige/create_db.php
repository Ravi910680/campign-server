<?php






function create_db($conn,$db_name){




$sql = "CREATE DATABASE ".$db_name;
if ($conn->query($sql) === TRUE) {

echo "create db ".$db_name;

}




}




function create_tbl_in_db($conn,$sql){



if($conn->query($sql)==TRUE){

echo "create Table ";

}




}






$servername = "campign.chmwcgvoxwwi.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";



$db_conn = mysqli_connect($servername, $username, $password);



#create all database

create_db($db_conn,"camp_analysis");

create_db($db_conn,"camp_email_db");

create_db($db_conn,"camp_hy");

create_db($db_conn,"camp_url_data");





$db_conn=mysqli_connect($servername, $username, $password,"camp_email_db");




$tbl_query="CREATE TABLE `camp_contact_tbl` (
  `camp_con_id` varchar(70) NOT NULL,
  `list_id` varchar(100) NOT NULL,
  `filt_data` varchar(100) NOT NULL,
  `merge_fld` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";






create_tbl_in_db($db_conn,$tbl_query);




$tbl_query="CREATE TABLE `camp_content_tbl` (
  `temp_id` varchar(150) NOT NULL,
  `sub_fld` varchar(100) NOT NULL,
  `prev_fld` varchar(100) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `smtp_id` int(11) NOT NULL,
  `camp_id` varchar(100) NOT NULL,
  PRIMARY KEY (`camp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";






create_tbl_in_db($db_conn,$tbl_query);





$tbl_query="CREATE TABLE `camp_name_tbl` (
  `id` varchar(30) NOT NULL,
  `camp_name` varchar(70) NOT NULL,
  `camp_contact_id` varchar(70) NOT NULL,
  `camp_content_data` varchar(70) NOT NULL,
  `camp_shed_time` datetime NOT NULL,
  `flg_send` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`camp_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";






create_tbl_in_db($db_conn,$tbl_query);







$db_conn=mysqli_connect($servername, $username, $password,"camp_hy");




$tbl_query="CREATE TABLE `camp_data` (
  `camp_name` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`camp_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";






create_tbl_in_db($db_conn,$tbl_query);




$db_conn=mysqli_connect($servername, $username, $password,"camp_url_data");




$tbl_query="CREATE TABLE `temp_url_data_crw` (
  `url_id` varchar(40) NOT NULL,
  `url` varchar(1000) NOT NULL,
  PRIMARY KEY (`url_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";






create_tbl_in_db($db_conn,$tbl_query);







?>