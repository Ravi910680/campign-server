
<style>




body{
  font-family: 'lato';
letter-spacing:0.2px;
}




  .dropdown-menu{
    border-radius:0px !important;
    box-shadow:none !important;
    
    border:1px solid #dedddc !important;
    
}

.nav-link:hover{
    cursor:pointer;
}

.nav-link{
    padding:20px;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}

.main-content {
    position: relative;
    top: 8vh;
}

a{
    font-weight:600;
}
  .navbar-light .navbar-brand {
    color: white;

  }


.dropdown-menu .dropdown-item>i, .dropdown-menu .dropdown-item>svg {
    margin-right: 1rem;

}

  .navbar-light .navbar-brand:hover, .navbar-light .navbar-brand:focus {
    color: white;

  }
  .navbar {
    background: #4a154b;
}



.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size:0.9rem !important;
    font-weight: 600;

padding: 20px 10px !important;
}

.dropdown-menu.show {
    border-radius: 10px !important;

}



.navbar-light .navbar-nav .nav-link:hover, .navbar-light .navbar-nav .nav-link:focus {
    color: white;

}


.navbar-light .navbar-nav .show>.nav-link, .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .nav-link.active {
    color: white;
}
.modal{

background: #00000070;

}



.c-slacklogo{display:flex;align-items:center;padding: 0px 20px;}
.c-slacklogo a{line-height:inherit;display:inline-block;font-size:0;padding:0;border:none}
.c-slacklogo img{vertical-align:top}
.c-slacklogo--white{display:none}
.c-slacklogo--color{display:inline-block}
@media screen and (min-width:67.8125rem){.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--white{display:inline-block}
.is-clear:not(.is-fixed) .c-slacklogo .c-slacklogo--color{display:none}
}
.c-slacklogo--pillow{width:auto;fill:#fff}
.c-slacklogo.v-frontiers{width:205px;z-index:1}
.c-nav__mobile .c-slacklogo.v-frontiers svg{margin-left:1rem}

.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
    color: white;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}


.navbar-light .navbar-nav .nav-link {
    color: white !important;
    font-size: 2vh;
    font-weight: 600;
    padding: 2.5vh 10px !important;
  }


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;

    }

    button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
  }

  .dropdown-caret {
    display: inline-block;
    width: 0;
    height: 0;
    vertical-align: middle;
    content: "";
    border-top-style: solid;
    border-top-width: 4px;
    border-right: 4px solid transparent;
    border-bottom: 0 solid transparent;
    border-left: 4px solid transparent;

  }

  #main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}


 @media only screen and (max-width: 480px) {


.navbar {
    height: auto !important;
    background: #4a154b;
}


}


@media (min-width: 320px) and (max-width: 480px) {



.navbar {
    height: auto !important;
    background: #4a154b;
}


}




.vert-cent-div {
  width: min-content;
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.info-err-img{
  height: 200px;
}



.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000b8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
}

button.gt-head-btn {
    background: white;
    border: none;
    color: #520726;
    padding: 5px 20px;
    font-size: 12px;
    font-weight: 700;
    border-radius: 5px;
    transition:.5s;
    margin-left: 50px;
  }

  button.gt-head-btn:hover {
    cursor: pointer;
    background: #840a3ccc;
    color: white;
  }



  .dropdown-item:hover{

cursor: pointer;
  }

  .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
  }
  .dropdown-item {
    border-radius: 10px;
  }










  .name-of-usr {
    font-size: 12px;
    padding: 5px;
    color: black;
    height: fit-content;
    display: inline-block;
    white-space: nowrap;
    overflow: hidden !important;
    text-overflow: ellipsis;
    width: 140px;
  }

  img.icon-img-of-usr {
    height: 28px;
    border-radius: 100px;
    margin-right: 10px;
  }

  a{
text-decoration:none;
}
  </style>



<nav class="navbar navbar-expand-lg navbar-light" style="height:8vh;width:100%;z-index:100000000;padding:0px;border-bottom-left-radius: 100px;">

<div class=" navbar-collapse">
<button class="gt-head-btn com-for-lnk" data-for-serv="1" data-path-ses="dashboard/" data-target-link="https://dashboard.auftera.com/dashboard/">Go To Dashboard</button>
</div>
<ul class="navbar-nav align-items-center d-none d-md-flex">
<li class="nav-item dropdown" style="
    color: white;
">
<svg class="octicon octicon-bell" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" style="fill:white;
"><path d="M8 16a2 2 0 001.985-1.75c.017-.137-.097-.25-.235-.25h-3.5c-.138 0-.252.113-.235.25A2 2 0 008 16z"></path><path fill-rule="evenodd" d="M8 1.5A3.5 3.5 0 004.5 5v2.947c0 .346-.102.683-.294.97l-1.703 2.556a.018.018 0 00-.003.01l.001.006c0 .002.002.004.004.006a.017.017 0 00.006.004l.007.001h10.964l.007-.001a.016.016 0 00.006-.004.016.016 0 00.004-.006l.001-.007a.017.017 0 00-.003-.01l-1.703-2.554a1.75 1.75 0 01-.294-.97V5A3.5 3.5 0 008 1.5zM3 5a5 5 0 0110 0v2.947c0 .05.015.098.042.139l1.703 2.555A1.518 1.518 0 0113.482 13H2.518a1.518 1.518 0 01-1.263-2.36l1.703-2.554A.25.25 0 003 7.947V5z"></path></svg>
</li>
<li class="nav-item dropdown" style="
    width: fit-content;
    margin-right: 10px;
    margin-left: 10px;
">
<a class=" pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
<div class="media align-items-center" style="
">
<div class="media-body ml-2 d-none d-lg-block" style="
    padding: 3px;
    background: white;
    border-radius: 100px;
    display: inline-flex !important;
    margin-left: 0px !important;
">
<img class="icon-img-of-usr" src="https://res.cloudinary.com/heptera/image/upload/a_-90/v1638507628/landing/open-collective_1_m4opwf_a7zjga.png"><div class="name-of-usr" style="
">
<?php echo $email;?></div>
<img src="https://res.cloudinary.com/heptera/image/upload/v1632374849/header/arrow_drop_down_black_24dp_1_z9tezk.svg" style="
    padding-right: 10px;
"></div>
</div>
</a>
<div class="dropdown-menu dropdown-menu-right" style="
    width: 100%;
    margin-top: 5px;
">

<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sites/add_sites/beta/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8C6.74028 8 7.38663 7.5978 7.73244 7H14C15.1046 7 16 7.89543 16 9C16 10.1046 15.1046 11 14 11H10C7.79086 11 6 12.7909 6 15C6 17.2091 7.79086 19 10 19H16.2676C16.6134 19.5978 17.2597 20 18 20C19.1046 20 20 19.1046 20 18C20 16.8954 19.1046 16 18 16C17.2597 16 16.6134 16.4022 16.2676 17H10C8.89543 17 8 16.1046 8 15C8 13.8954 8.89543 13 10 13H14C16.2091 13 18 11.2091 18 9C18 6.79086 16.2091 5 14 5H7.73244C7.38663 4.4022 6.74028 4 6 4C4.89543 4 4 4.89543 4 6C4 7.10457 4.89543 8 6 8Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Connected App </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sender/add_sender/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Sender Profile</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/smtp/add_smtp/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 6C8.44772 6 8 6.44772 8 7C8 7.55228 8.44772 8 9 8H15C15.5523 8 16 7.55228 16 7C16 6.44772 15.5523 6 15 6H9Z" fill="currentColor"></path><path d="M9 10C8.44772 10 8 10.4477 8 11C8 11.5523 8.44772 12 9 12H15C15.5523 12 16 11.5523 16 11C16 10.4477 15.5523 10 15 10H9Z" fill="currentColor"></path><path d="M13 17C13 17.5523 12.5523 18 12 18C11.4477 18 11 17.5523 11 17C11 16.4477 11.4477 16 12 16C12.5523 16 13 16.4477 13 17Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 5C4 3.34315 5.34315 2 7 2H17C18.6569 2 20 3.34315 20 5V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5ZM7 4H17C17.5523 4 18 4.44772 18 5V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
SMTP Server </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/emb/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3H3V9H5V5H9V3ZM3 21V15H5V19H9V21H3ZM15 3V5H19V9H21V3H15ZM19 15H21V21H15V19H19V15ZM7 7H11V11H7V7ZM7 13H11V17H7V13ZM17 7H13V11H17V7ZM13 13H17V17H13V13Z" fill="currentColor"></path></svg><span class="padding-left:10px;">
Integration </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="dev/" data-target-link="https://dev.auftera.com/dev/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 14V20H10V18H6V14H4Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M9 9V15H15V9H9ZM13 11H11V13H13V11Z" fill="currentColor"></path><path d="M4 10V4H10V6H6V10H4Z" fill="currentColor"></path><path d="M20 10V4H14V6H18V10H20Z" fill="currentColor"></path><path d="M20 14V20H14V18H18V14H20Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
API</span></button>
<div class="dropdown-divider"></div>
<button class="dropdown-item comm_up_btn com-for-lnk" data-path-ses="account/" data-for-serv="1" data-target-link="http://account.auftera.com/account/plan/recent/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Plan</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-path-ses="account/" data-for-serv="1" data-target-link="http://account.auftera.com/account/confige/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor"></path><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Log Out</span></button>
</div>


</li>
</ul>
</nav>



