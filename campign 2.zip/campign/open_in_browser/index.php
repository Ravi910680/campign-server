<?php



require("../confige/fileconfige.php");



function select_query($conn,$sel_query){


        $ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}
$id=$_GET['con_id'];
$lst_id=$_GET['lst_name'];
$temp_name=urlencode($_GET['save_temp_name']);
$sel_query="select * from `$lst_id` where con_id='$id'";



$query_of_temp=http_build_query(select_query($conn3,$sel_query)[0]);


$get_html_con=json_decode(file_get_contents("https://campign.auftera.com/campign/camp_temp/".$temp_name."?".$query_of_temp))->content_for_send;
echo $get_html_con;
 ?>

